const express= require("express");
const path=require('path');
const index= express();
const port= 3000;

index.use(express.static(path.join(__dirname,'public')));
index.get('/', (req,res) => {
    res.send("Hello world")
});

index.get('/day3', (req,res) => {
    res.sendFile(path.join(__dirname,'public','day3.html'))
});
index.get('/day5', (req,res) => {
    res.sendFile(path.join(__dirname,'public','day5.html'))
});
index.get('/detailday5', (req,res) => {
    res.sendFile(path.join(__dirname,'public','detailday5.html'))
});


index.listen(port, () => {
    console.log(`aplikasi ini berjalan di port:${port}`)
});